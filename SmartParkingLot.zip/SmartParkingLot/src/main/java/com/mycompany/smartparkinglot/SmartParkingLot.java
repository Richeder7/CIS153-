package com.mycompany.smartparkinglot;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.Scanner;
import java.util.ArrayList;

public class SmartParkingLot {

    // -----------------------------------------
    // DATA STRUCTURES
    // -----------------------------------------

    private static Queue<Car> waitingQueue = new LinkedList<>();
    private static Stack<Car> parkingStack = new Stack<>();
    private static final int MAX_SPOTS = 5;

    // CAR CLASS
    static class Car {
        int id;
        String time;

        public Car(int id, String time) {
            this.id = id;
            this.time = time;
        }

        @Override
        public String toString() {
            return "Car " + id + " (Time: " + time + ")";
        }
    }

    // -----------------------------------------
    // MAIN MENU
    // -----------------------------------------

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\n====== SMART PARKING LOT SYSTEM ======");
            System.out.println("1. Add Car (Enter)");
            System.out.println("2. Remove Car (Exit)");
            System.out.println("3. View Waiting Queue");
            System.out.println("4. View Parking Lot");
            System.out.println("5. Sort Cars by ID");
            System.out.println("6. Exit Program");
            System.out.print("Choose: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> addCar(sc);
                case 2 -> removeCar(sc);
                case 3 -> viewWaitingQueue();
                case 4 -> viewParkingStack();
                case 5 -> sortCars();
                case 6 -> {
                    System.out.println("Program Finished.");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    // -----------------------------------------
    // FUNCTIONS
    // -----------------------------------------

    // Add a car (Queue → Stack)
    private static void addCar(Scanner sc) {
        System.out.print("Enter Car ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Time of Arrival: ");
        String time = sc.nextLine();

        Car newCar = new Car(id, time);

        if (parkingStack.size() < MAX_SPOTS) {
            parkingStack.push(newCar);
            System.out.println("Car parked: " + newCar);
        } else {
            waitingQueue.add(newCar);
            System.out.println("Parking full! Added to waiting queue.");
        }
    }

    // Remove a car (Stack logic)
    private static void removeCar(Scanner sc) {
        if (parkingStack.isEmpty()) {
            System.out.println("Parking is empty.");
            return;
        }

        System.out.print("Enter ID of car leaving: ");
        int targetID = sc.nextInt();

        Stack<Car> tempStack = new Stack<>();
        Car removedCar = null;

        // Move cars until we reach the target
        while (!parkingStack.isEmpty()) {
            Car topCar = parkingStack.pop();

            if (topCar.id == targetID) {
                removedCar = topCar;
                break;
            } else {
                tempStack.push(topCar);
            }
        }

        // Put cars back
        while (!tempStack.isEmpty()) {
            parkingStack.push(tempStack.pop());
        }

        if (removedCar != null) {
            System.out.println("Removed: " + removedCar);

            // Move next waiting car into parking
            if (!waitingQueue.isEmpty()) {
                Car nextCar = waitingQueue.poll();
                parkingStack.push(nextCar);
                System.out.println("Moved from queue to parking: " + nextCar);
            }
        } else {
            System.out.println("Car not found in parking lot.");
        }
    }

    // View waiting queue
    private static void viewWaitingQueue() {
        System.out.println("\n--- WAITING QUEUE ---");
        if (waitingQueue.isEmpty()) {
            System.out.println("Queue is empty.");
        } else {
            for (Car c : waitingQueue) {
                System.out.println(c);
            }
        }
    }

    // View parking stack
    private static void viewParkingStack() {
        System.out.println("\n--- PARKING LOT (STACK) ---");
        if (parkingStack.isEmpty()) {
            System.out.println("Parking lot is empty.");
        } else {
            for (Car c : parkingStack) {
                System.out.println(c);
            }
        }
    }

    // Sort cars by ID using Bubble Sort
    private static void sortCars() {
        System.out.println("\nSorting cars by ID...");

        ArrayList<Car> allCars = new ArrayList<>(parkingStack);

        // Bubble sort
        for (int i = 0; i < allCars.size() - 1; i++) {
            for (int j = 0; j < allCars.size() - i - 1; j++) {
                if (allCars.get(j).id > allCars.get(j + 1).id) {
                    Car temp = allCars.get(j);
                    allCars.set(j, allCars.get(j + 1));
                    allCars.set(j + 1, temp);
                }
            }
        }

        System.out.println("Cars sorted:");
        for (Car c : allCars) {
            System.out.println(c);
        }
    }
}
